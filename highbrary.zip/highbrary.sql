-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2020 at 03:21 PM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `highbrary`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `author` text NOT NULL,
  `category_name` text NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `postDateTime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `author`, `category_name`, `description`, `image`, `price`, `postDateTime`) VALUES
(1, 'Rich Dad Poor Dad', 'Robert Kiyosaki', 'Novels', 'This is most popular book.', '1582101848_2.jpg', 200, '2020-02-19 09:44:08'),
(2, 'Rich Dad Poor Dad', 'robert', 'Novels', 'dasf', '1582101997_6.jpg', 2332, '2020-02-19 09:46:37'),
(3, 'Impression', 'Abhimanyu', 'Novels', 'This is third book.', '1583412752_5.jpg', 300, '2020-03-05 13:52:32'),
(4, 'adfasd', 'asdf', 'Novels', 'adsfadsf dsfkajlasd sdalfjl', '1583412782_9.jpg', 400, '2020-03-05 13:53:02'),
(5, 'ljlkjlkj', 'jlkjlkjl', 'Novels', 'ojlkjkljkldsaf dsafnasdfn', '1583412805_7.jpg', 760, '2020-03-05 13:53:25'),
(6, 'asdfou', 'w3rmewm', 'Novels', 'jasdflkjlkj afdskljldasjfljds aflkljadslf', '1583412830_4.jpg', 321, '2020-03-05 13:53:50'),
(7, 'dsafadsjflk asdfljlkadsjfl sdafkljlasdf', 'jasdlfk', 'Novels', 'adfjlkjsaldkfjl sadfkjlaskdjfl', '1583412886_2.jpg', 200, '2020-03-05 13:54:46');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `profile_image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `profile_image`) VALUES
(1, 'anuj', 'anuj@gmail.com', 'anuj', 'img/default_profile.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
